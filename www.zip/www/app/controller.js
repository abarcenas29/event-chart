function chartControll($scope,$http,$location){
    var city = 'all';
    var newAppOrigin = appOrigin2 + '?callback=JSON_CALLBACK&city='+city;
          
    $http.jsonp(newAppOrigin).success(function(d){
        $scope.events = d;
    });
    
    $scope.eventDetail = function(eventId){
        sessionStorage.selectedEvent = eventId;
        $location.path('/event');
    };
}

function eventViewControll($scope,$http){
    var eventId = sessionStorage.selectedEvent;
    var newAppEvent = appEvent + '?callback=JSON_CALLBACK&event_id='+eventId;
    
    $http.jsonp(newAppEvent).success(function(d){
        console.log(d);
        $scope.event = d;
    });
}