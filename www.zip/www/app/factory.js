var chartService = {
    fecthChart : function($scope){
        console.log($scope);
    }
}