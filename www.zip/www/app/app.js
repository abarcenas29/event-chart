//constants
var appOrigin2  = 'http://event.deremoe.com/api/vendor/events2';
var appEvent    = 'http://event.deremoe.com/api/vendor/detail_event';

var appOrigin   = 'http://event.chart.local/api/vendor/events.json';

angular.module('App',['ngRoute'])
    .config(function ($routeProvider) {
        
    $routeProvider
    .when('/chart', {
        controller: chartControll,
        templateUrl: 'view/chart.html'
    })
    .when('/event', {
        controller: eventViewControll,
        templateUrl: 'view/event.html'
    })
    .otherwise({redirectTo:'/chart'});
});